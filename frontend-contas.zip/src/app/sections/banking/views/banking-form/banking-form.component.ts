import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-banking-form',
  templateUrl: './banking-form.component.html',
  styleUrls: ['./banking-form.component.scss']
})
export class BankingFormComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
