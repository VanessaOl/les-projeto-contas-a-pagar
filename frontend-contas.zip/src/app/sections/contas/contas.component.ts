import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-contas',
  templateUrl: './contas.component.html',
  styleUrls: ['./contas.component.scss']
})
export class ContasComponent implements OnInit {

  displayForm: boolean;

  constructor() { }

  ngOnInit() {
  }

  toggleForm() {
    this.displayForm = !this.displayForm;
  }

}
